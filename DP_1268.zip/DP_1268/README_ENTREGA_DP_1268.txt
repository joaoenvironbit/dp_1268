# Entrega DP-1268 — Dicionário consolidado e padronização proposta

## 1. Objetivo da DP_1268

Consolidar o dicionário das bases estaduais de acidentes do projeto João / EnvironBIT, produzindo equivalências sugeridas, campos canônicos propostos, padronizações necessárias, aderência ao padrão EnvironBIT e priorização para **implementação futura** — sem alterar dados brutos e sem executar pipeline produtivo.

## 2. Fontes utilizadas

| Fonte | Uso |
|-------|-----|
| `evidencias_internas/rascunho_equivalencias.csv` | Equivalências campo a campo (590 linhas) |
| `evidencias_internas/rascunho_canonicos.csv` | Campos canônicos propostos (247 linhas) |
| `evidencias_internas/rascunho_padronizacoes.csv` | Necessidades de transformação (590 linhas) |
| `evidencias_internas/pacotes_decisao_semantica.csv` | Pacotes semânticos validados (49 pacotes) |
| `Padronização de Arquivos e Estrutura.docx` | Referência normativa EnvironBIT |
| Artefatos DP_1267 (somente leitura) | Baseline técnico-documental |

## 3. Relação com a DP_1267

A **DP_1267** permanece como baseline técnico-documental (dicionário inicial, campos essenciais, completude, revisão humana). A **DP_1268** reutiliza esse baseline para consolidar semântica e padronização proposta. **Nenhum arquivo da DP_1267 foi alterado** nesta entrega.

## 4. Artefatos entregues

| Arquivo | Descrição |
|---------|-----------|
| `WORKBOOK_DP_1268_DICIONARIO_CONSOLIDADO.xlsx` | Workbook consolidado (15 abas) |
| `README_ENTREGA_DP_1268.md` | Este guia |

## 5. Estrutura do workbook

O workbook final possui **15 abas**:

1. **resumo_executivo** — síntese objetiva da atividade e contagens
2. **dicionario_consolidado** — visão unificada origem → canônico proposto
3. **equivalencias_sugeridas** — equivalências propostas (coluna final humana vazia; não chanceladas)
4. **campos_canonicos** — conceitos canônicos propostos
5. **padronizacoes_necessarias** — renomeação, tipos, datas, encoding, espacial
6. **campos_removidos_core** — linhas excluídas do core por origem não estadual
7. **canonicos_removidos_core** — canônicos órfãos removidos do core
8. **aderencia_environbit** — diagnóstico por dimensão do padrão institucional
9. **priorizacao_implementacao** — fila sugerida alta / média / baixa
10. **excecoes_revisao_futura** — pacotes excepcionais não promovidos ao core
11. **observacoes_semanticas_dp1267** — evidência DP_1267 não consolidada (29 casos)
12. **revisao_humana_semantica** — pacote explícito de revisão humana (9 casos)
13. **possiveis_intervalos_confianca** — hipóteses documentais para família ic_5 / ic_10
14. **diagnostico_pendentes_valores** — diagnóstico read-only de exemplos pendentes
15. **fechamento_semantico** — decisões finais para casos especiais (28 linhas; não altera o core)

## 6. Decisões metodológicas

- Distinção explícita entre **status sugerido** e **status final humano** (vazio).
- A aba **equivalencias_sugeridas** contém equivalências **propostas** para a DP_1268; `status_equivalencia_final` permanece vazio até chancela humana posterior.
- Equivalências permanecem como **sugestões confirmáveis/prováveis** — não como decisão final automática.
- Componentes temporais isolados (mês, ano, dia da semana) **não** são convertidos para data ISO completa.
- Métricas derivadas, campos GIS/técnicos e colunas opacas permanecem **fora do core canônico**.
- Blocos internos de validação foram concluídos; os detalhes permanecem nos artefatos de evidência em `evidencias_internas/`.

## 7. Resumo das validações por blocos

Os blocos internos da atividade (pacotes base, temporais, rodoviário, pessoas/veículos, auxiliares e exceções) foram validados terminalmente; o detalhamento por bloco permanece nos CSVs e validações técnicas da pasta `evidencias_internas/`.

## 8. Limitações documentadas

- Colunas `*_final` e `status_equivalencia_final` permanecem vazias aguardando chancela humana.
- 151 equivalências marcadas como `exige_revisao_adicional`.
- 131 equivalências `fora_do_escopo_canonico`.
- A DP_1268 documenta padronizações necessárias para implementação futura; **não executa pipeline produtivo** de tratamento dos dados.
- A classificação de encoding **orienta** a futura implementação; não constitui correção produtiva do encoding.
- `latin1` indica necessidade de **decisão/conversão para UTF-8** na padronização futura; não é automaticamente “erro de dados”.
- `desvio_environbit_identificado` é **derivado** das colunas `necessidade_*` (nomenclatura, encoding, datas, categorias/texto, tipos e critérios espaciais).
- Heterogeneidade de exemplos em pacotes de pessoas/envolvidos exige validação amostral.

A necessidade de ajuste de encoding foi registrada como dimensão de padronização futura em `padronizacoes_necessarias`. A classificação final está refletida no workbook e nos artefatos de evidência internos. O README não detalha o histórico de reclassificações, que permanece documentado nos CSVs e validações técnicas da pasta `evidencias_internas/`.

## Fechamento semântico da DP_1268

A DP_1268 possui uma camada final de fechamento semântico para casos especiais. Essa camada documenta decisões finais sem alterar o core do dicionário (`rascunho_equivalencias.csv`, `rascunho_canonicos.csv`, `rascunho_padronizacoes.csv`).

**Artefato fonte:** `evidencias_internas/FECHAMENTO_SEMANTICO_DP1268.csv` (28 linhas)

**Incorporação no workbook:** aba `fechamento_semantico`

A camada de fechamento semântico não altera o core do dicionário. Ela documenta decisões finais para casos especiais, distinguindo campos consolidados, limitações documentadas e dependências externas. Campos sem evidência suficiente não foram promovidos por inferência lexical.

### Composição do fechamento

| Grupo | Linhas | Descrição |
|-------|-------:|-----------|
| `consolidado_com_significado` | 14 | Campos com significado consolidado (inclui linha agregada dos 97 significados fortes — não expandida individualmente) |
| `nao_consolidado_evidencia_insuficiente` | 1 | Campo sem promoção por evidência insuficiente |
| `dependente_legenda_externa` | 1 | Campo dependente de glossário externo |
| `limitacao_metodologica` | 12 | Família `ic_5` / `ic_10` fechada com restrição metodológica |

### Casos com limitação documentada

**`obs`** — permanece sem significado consolidado porque não há coluna física única rastreável nas evidências disponíveis. Os exemplos encontrados são notas editoriais de curadoria, não valores de domínio. Variantes como `trechoobs`, `convobs` e `Observação` aparecem separadamente, com domínios próprios. Status: `fechado_com_limitacao_documentada`. Esta limitação documentada não bloqueia a entrega da DP_1268.

**`peso_tipo_acidente`** — permanece sem significado consolidado porque depende de legenda externa dos códigos 1 a 13. A coluna física foi localizada, mas a documentação disponível não fornece glossário formal para consolidar o significado dos códigos. Status: `fechado_dependente_externo` (dependência externa).

**Família `ic_5` / `ic_10`** (12 campos anuais) — permanece sem significado consolidado. Há evidência parcial de associação com métrica estatística ligada à Taxa de Severidade e ao método CQT, mas a documentação disponível não define formalmente IC_5%, IC_10%, IC_0,5% nem a relação IC ↔ Ts. Status: `fechado_com_limitacao_metodologica` para todos os 12 campos. Esta restrição metodológica não bloqueia a entrega da DP_1268.

## 9. Exceções mantidas para revisão futura

14 pacotes/categorias documentados na aba `excecoes_revisao_futura`, incluindo:

- Campos opacos e códigos curtos ambíguos (`cd_sit`, `check`, `cide`, `consr`)
- Data histórica ambígua (`dendat`)
- Envolvimento e faixa etária
- Métricas anuais derivadas e incerteza estatística
- Metadados GIS e índices geográficos opacos

Essas exceções **não são equivalências validadas** e **não devem ser promovidas automaticamente** ao core.

## 10. Confirmações finais

- [x] **Dados brutos não foram alterados.**
- [x] **Arquivos da DP_1267 não foram alterados.**
- [x] **A DP_1268 não implementa pipeline produtivo.**
- [x] **A DP_1268 consolida dicionário, equivalências, canônicos, padronizações e priorização para implementação futura.**
- [x] **Colunas finais humanas permanecem vazias quando previstas.**
- [x] **Exceções do Bloco 6 permanecem como exceções documentadas.**

---

### Contagens principais (rascunhos de entrada)

| Indicador | Valor |
|-----------|------:|
| Linhas em equivalências | 590 |
| Campos canônicos propostos | 247 |
| Linhas de padronização | 590 |
| Pacotes semânticos | 49 |
| Exceções documentadas | 14 |

**status_equivalencia_sugerido:** equivalencia_provavel: 191, exige_revisao_adicional: 151, fora_do_escopo_canonico: 131, equivalencia_confirmavel: 117

**status_canonico_sugerido:** exige_revisao_adicional: 149, auxiliar_nao_canonico: 48, canonico_provavel: 39, canonico_confirmavel: 11

**prioridade_implementacao_sugerida:** baixa: 322, alta: 252, media: 16
